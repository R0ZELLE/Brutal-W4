# Disturb Me

* install
  ```python
  pkg update
  pkg upgrade
  apt install git make
  apt install python
  git clone https://github.com/Bayu12345677/Disturb-Me
  cd Disturb-Me
  make setup
  make Run
  ```

<h2>Peraturan</h2><br>
<span><div>
  - Dilarang Membagikan token kepada siapapun<br>
    Konsekuensi script akan di nonaktifkan dan di hapus !!
</div></span>
<br>
<br>
<summary>jenis spam</summary>
<code>
  - Spam Wa<br>
  - Spam Sms
</code>

# By Pejuang Kentang
